﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simp
{
    public class LargeEmployee : Employee
    {
        byte[] someData = { };
    }
}
